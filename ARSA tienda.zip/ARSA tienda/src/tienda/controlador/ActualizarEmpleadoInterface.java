package tienda.controlador;

public interface ActualizarEmpleadoInterface {
	
	public void actualizarPosicion(String dni, String tipoEmpleado);
}
