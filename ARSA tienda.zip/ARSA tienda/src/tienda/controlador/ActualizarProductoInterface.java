package tienda.controlador;

public interface ActualizarProductoInterface {
	
	public void actualizarProducto(String codProducto, String nombreProducto, String seccionProducto, double precio, int stock);
}
