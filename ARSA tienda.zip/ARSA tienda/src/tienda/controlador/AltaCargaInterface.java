package tienda.controlador;

public interface AltaCargaInterface {
	
	public void crearCarga(String dni);
}
