package tienda.controlador;

public interface AltaProductoInterface {
	
	public void altaProducto(String nombreProducto, String seccionProducto, String fechaCaducidad, double precio, int stock);
}
