package tienda.controlador;

public interface BajaProductoInterface {
	
	public void borrarProducto(String nombreProducto);
	
}
