package tienda.controlador;

public interface IncrementarSueldoInterface {
	
	public void incrementarSueldoEmpleados(int porcentaje);
	
	public void incrementarSueldoEmpleados(int porcentaje, String dni);
}
