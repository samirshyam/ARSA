package tienda.controlador;

public interface ListaCargaInterface {
	
	public String[][] listarCargas();
}
