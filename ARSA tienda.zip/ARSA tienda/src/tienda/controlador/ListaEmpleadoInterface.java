package tienda.controlador;

public interface ListaEmpleadoInterface {
	
	public String[][] listarEmpleados();
}
