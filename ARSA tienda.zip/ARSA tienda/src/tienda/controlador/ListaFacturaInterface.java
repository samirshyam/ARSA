package tienda.controlador;

public interface ListaFacturaInterface {
	
	public String[][] listarFacturas();
}
