package tienda.controlador;

public interface ListaProductoInterface {
	
	public String[][] listarProductos();
}
