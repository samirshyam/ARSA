package tienda.vistas;

import javax.swing.JPanel;

public class altaEmpleado extends JPanel {

	/**
	 * Create the panel.
	 */
	public altaEmpleado() {

	}

}
