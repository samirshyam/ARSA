package tienda.vistas;

import javax.swing.JPanel;

public class altaProducto extends JPanel {

	/**
	 * Create the panel.
	 */
	public altaProducto() {

	}

}
