package tienda.vistas;

import javax.swing.JPanel;

public class bajaEmpleado extends JPanel {

	/**
	 * Create the panel.
	 */
	public bajaEmpleado() {

	}

}
