package tienda.vistas;

import javax.swing.JPanel;

public class bajaProducto extends JPanel {

	/**
	 * Create the panel.
	 */
	public bajaProducto() {

	}

}
