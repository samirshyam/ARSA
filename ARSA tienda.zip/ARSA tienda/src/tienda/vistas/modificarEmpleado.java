package tienda.vistas;

import javax.swing.JPanel;

public class modificarEmpleado extends JPanel {

	/**
	 * Create the panel.
	 */
	public modificarEmpleado() {

	}

}
