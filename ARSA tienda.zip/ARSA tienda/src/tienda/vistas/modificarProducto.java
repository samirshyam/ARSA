package tienda.vistas;

import javax.swing.JPanel;

public class modificarProducto extends JPanel {

	/**
	 * Create the panel.
	 */
	public modificarProducto() {

	}

}
